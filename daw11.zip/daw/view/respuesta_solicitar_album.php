<?php
    require_once("view/cabecera_privada.php");
?>

<main>
    <section id="seccion">
        <h2>Resultado de solicitud de impresión de álbum</h2>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Possimus perferendis atque ipsum provident dolorem! Eius enim unde ea veniam eum nihil commodi quod itaque quaerat ipsum! Debitis quibusdam enim aliquid.</p>
    </section>

    <div>
        <fieldset>
            <legend>Confirmación de Solicitud</legend>
            <p>Gracias por solicitar un álbum. A continuación, se muestran los datos que has proporcionado:</p>
            <p>Nombre: <strong><?php echo $_POST['nombre']; ?></strong></p>
            <p>Título del álbum: <strong><?php echo $_POST['titulo']; ?></strong></p>
            <p>Texto adicional: <strong><?php echo $_POST['texto_ad']; ?></strong></p>
            <p>Correo electrónico: <strong><?php echo $_POST['correo']; ?></strong></p>
            <p>Dirección: <strong><?php echo $_POST['direccion']; ?></strong></p>
            <p>Número: <strong><?php echo $_POST['numero']; ?></strong></p>
            <p>CP: <strong><?php echo $_POST['cp']; ?></strong></p>
            <p>Localidad: <strong><?php echo $_POST['ciudad']; ?></strong></p>
            <p>Provincia: <strong><?php echo $_POST['provincia']; ?></strong></p>
            <p>Teléfono: <strong><?php echo $_POST['telefono']; ?></strong></p>
            <p>Color de portada: <input type="color" id="color_portada" name="color_portada" value="#000000" disabled></p>
            <p>Número de copias: <strong><?php echo $_POST['copias']; ?></strong></p>
            <p>Número de fotos: <strong><?php echo $_POST['numFotos']; ?></strong></p>
            <p>Resolución de impresión: <strong><?php echo $_POST['res']; ?></strong></p>
            <p>Álbum de SUNEGAMI: <strong><?php echo $_POST['album']; ?></strong></p>
            <p>Fecha de recepción: <strong><?php echo $_POST['fecha1']; ?></strong></p>
            <p>Impresión a color: <strong><?php echo isset($_POST['impresion']) ? 'Sí' : 'No'; ?></strong></p>
            <?php
            require_once("controller/clc_album.php");
            ?>
            <p id="Coste"><strong>Coste del álbum: <?php echo number_format($costoTotal, 2); ?> €</strong></p>
            <p id="infoResultado">Recibirás un correo electrónico de confirmación con más detalles. Gracias por elegir nuestros servicios.</p>
        </fieldset>
    </div>
</main>

<?php
require_once('view/pie.php');
?>
<!--
    <main> 
        <section id="seccion">
            <h2>Resultado de solicitud de impresión de álbum </h2>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Possimus perferendis atque ipsum provident dolorem! Eius enim unde ea veniam eum nihil commodi quod itaque quaerat ipsum! Debitis quibusdam enim aliquid.</p>
        </section>
            <div>
                <fieldset>
                <legend>Confirmación de Solicitud</legend>
                <p>Gracias por solicitar un álbum. A continuación, se muestran los datos que has proporcionado:</p>
                <p>Nombre: <strong> Don Pedro Tablones</strong></p>
                <p>Título del álbum: <strong>El increíble viaje por la playa de murcia</strong></p>
                <p>Texto adicional: <strong>Dedicado a todo el mundo que haya podido observar la playa de murcia</strong></p>
                <p>Correo electrónico: <strong>pedro.cortatablones@gmail.com></strong></p>
                <p>Dirección: <strong>Calle Murcia</strong></p>
                <p>Número: <strong>99</strong></p>
                <p>CP: <strong>30001</strong></p>
                <p>Localidad: <strong>Tobarra</strong></p>
                <p>Provincia: <strong>Murcia</strong></p>
                <p>Teléfono: <strong>666 666 666</strong></p>
                            
                <p>Color de portada: <input type="color" id="color_portada" name="color_portada" value="#000000" disabled></p>
                <p>Número de copias: <strong>1</strong></p>
                <p>Resolución de impresión: <strong>900</strong></p>
                <p>Álbum de SUNEGAMI: <strong>Álbum 1</strong></p>
                <p>Fecha de recepción: <strong>32/3/2079</strong></p>
                <p>Impresión a color: <strong>Si</strong></p>
                <p id="Coste"><strong>Coste del álbum: $99.00</strong></p>
                <p id="infoResultado">Recibirás un correo electrónico de confirmación con más detalles. Gracias por elegir nuestros servicios.</p>
            </fieldset>
        </div>
    </main>
-->