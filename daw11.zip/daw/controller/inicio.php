<?php
include('./model/conexion.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nombre']) && isset($_POST['pass'])) {
    $usuario = $_POST['nombre'];
    $contrasena = $_POST['pass'];

    // Realizar la consulta sin prevención de inyección SQL
    $result = mysqli_query($connect, "SELECT * FROM usuarios WHERE NomUsuario = '$usuario'");

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verificar la contraseña usando password_verify
        if ($contrasena == $row['Clave']) {
            // Las credenciales son correctas
            // Asignar las sesiones
            $_SESSION["usuario"] = $usuario;
            $_SESSION["psw"] = $contrasena;
            $_SESSION["estilo"] = $row['Estilo'];

            // Configurar cookies para recordar al usuario durante 90 días
            if (isset($_POST["remember"]) && $_POST["remember"] == "on") {
                setcookie("usuario", $usuario, time() + 90 * 24 * 60 * 60);
                setcookie("psw", $contrasena, time() + 90 * 24 * 60 * 60);
                setcookie("ultima_visita", date("Y-m-d H:i:s"), time() + 90 * 24 * 60 * 60);
                setcookie("estilo", $row['Estilo'], time() + 90 * 24 * 60 * 60);
            } else {
                setcookie("usuario", $usuario);
                setcookie("psw", $contrasena);
                setcookie("ultima_visita", date("Y-m-d H:i:s"));
                setcookie("estilo", $row['Estilo']);
            }
            header('Location: ./'); // Redirigir a página de usuario registrado
            exit();
        } else {
          
          
            header('Location: errores?error=1'); 
          
        }
    } else {
        // Usuario no encontrado
        header('Location: errores?error=4'); // Redirigir con mensaje de error
        exit();
    }
}

if (isset($_GET["nombre_reg"]) && isset($_GET["pass_reg"]) && isset($_GET["pass2"])) {
    // Obtener los datos del formulario
    $username = $_GET["nombre_reg"];
    $password = $_GET["pass_reg"];
    $confirm_password = $_GET["pass2"];

    if (empty($username) || empty($password) || empty($confirm_password)) {
        header("Location: errores?error=1");
        exit();
    }
    // Validar que las contraseñas coincidan
    if ($password !== $confirm_password) {
        header("Location: errores?error=2"); // Redireccionar con mensaje de error
        exit();
    }
    // Validar nombre de usuario
    if (!preg_match('/^[a-zA-Z][a-zA-Z0-9]{2,14}$/', $username)) {
        header("Location: errores?error=1"); // Redireccionar con mensaje de error
        exit();
    }

    // Validar contraseña
    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d_\-]{6,15}$/', $password) || $password !== $confirm_password) {
        header("Location: errores?error=2"); // Redireccionar con mensaje de error
        exit();
    }

    // Validar dirección de email
    $email = isset($_GET["email"]) ? $_GET["email"] : '';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: errores?error=3"); // Redireccionar con mensaje de error
        exit();
    }

    // Validar sexo
    $sexo = isset($_GET["sexo"]) ? $_GET["sexo"] : '';
    if ($sexo !== 'masculino' && $sexo !== 'femenino') {
        header("Location: errores?error=4"); // Redireccionar con mensaje de error
        exit();
    }

    // Validar fecha de nacimiento
    $fecha_nacimiento = isset($_GET["fecha_nacimiento"]) ? $_GET["fecha_nacimiento"] : '';
    $fecha_actual = date('Y-m-d');
    $edad_minima = 18;
    if (strtotime($fecha_nacimiento) === false || strtotime($fecha_nacimiento) > strtotime("-$edad_minima years", strtotime($fecha_actual))) {
        header("Location: errores?error=5"); // Redireccionar con mensaje de error
        exit();
    }

    // Permitir que el usuario seleccione el estilo durante el registro
    $estilo = isset($_GET['estilo']) ? $_GET['estilo'] : 'estilo.css';

    // Insertar el nuevo usuario en la base de datos
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $result = mysqli_query($connect, "INSERT INTO usuarios (NomUsuario, Clave, Estilo) VALUES ('$username', '$hashed_password', '$estilo')");
    
    if ($result) {
        header('Location: registro_exitoso'); // Redirigir a página de registro exitoso
        exit();
    } else {
        header("Location: errores?error=3"); // Redireccionar con mensaje de error
        exit();
    }
}
?>