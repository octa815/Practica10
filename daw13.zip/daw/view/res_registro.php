<?php    
    require_once('view/cabecera.php');
?>
<?php
$username = $_GET["nombre_reg"];
$apelli = $_GET["apellidos"] ;
$password = $_GET["pass_reg"] ;
$confirm_password = ($_GET["pass2"]);
$email = $_GET["email_reg"];
$sex = isset($_GET["sexo"])? $_GET["sexo"]:'Prefiero no decirlo' ;
$fecha = $_GET["fecha1"];
$ciud = $_GET["ciudad"];
$pas = $_GET["pais"] ;  
echo <<<hereDoc
<main id=pag_error>
    <aside >
    
        <fieldset id="succes" >
        <legend>ENHORABUENA!!</legend>
        <p>Usuario  creado correctamente con los siguientes datos</p>
        <ul>
        <li>Usuario: $username</li>
        <li>Contraseña: $password</li>
        <li>Contraseña (repetida): $confirm_password</li>
        <li>Apellidos: $apelli</li>
        <li>Email: $email</li>
        <li>Sexo: $sex</li>
        <li>Fecha de nacimiento: $fecha</li>
        <li>Ciudad: $ciud</li>
        <li>País: $pas</li>
        </ul>
        <input type="button"  onclick="location.href='./';"value= "OK" />
        </fieldset>
        
    </aside>
    
</main>
hereDoc;
?>
<?php    
    require_once('view/inicio.php');
?>
<?php    
    require_once('view/pie.php');
?>