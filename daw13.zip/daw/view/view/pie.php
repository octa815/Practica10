        <footer class="pie">
        <p>&copy;
            <time datetime ="2023-09-25"> José Ángel Mercadillo & Octavio Gregorio </time>
            <abbr title = "DAW"> Practica 10 </abbr>
        </p>
        <p>
            <a href="accesibilidad" id="accesibilidad" class="icon-universal-access"><span>Accesibilidad</span></a>
        </p>
        </footer> 
        <script>
        login();
        registro();
    </script>
    </body>
</html>

