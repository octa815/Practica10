<?php
  include("view/cabecera_privada.php");
  include('model/conexion.php');
  include('model/album.php');
?>
<main>
<section id=album>
  <h2>ALBUM</h2>
  <?php
  if (!empty($albumes)) {
    foreach ($informacion as $fila) {
    echo <<<hereDOC
    <aside class=info>
    <h2>Informacion</h2>
    <figure>
      <fieldset>
        {$fila["tituloalbum"]}
      </fieldset> 
      <footer>
          <fieldset>
              <legend>{$fila["NomUsuario"]}</legend>
              <p>numero de fotos en el album: {$fila["numfoto"]} </p>
              <p>{$fila["descalbum"]}</p>
          </fieldset> 
      </footer>
    </figure>
    </aside>
    hereDOC;
  }
 }else {
  echo <<<hereDOC
  <fieldset>
    <p>No se encontraron resultados para este álbum.</p>
  </fieldset> 
  hereDOC;
 }
?>
 <aside class=fotos>
    <?php
   foreach ($albumes as $row) {
    echo <<<hereDOC
        <figure>
          <a href="detalle?idFoto={$row['IdFoto']}"><img src="{$row["Fichero"]}"></a>
          <footer>
            <fieldset>
            <legend>{$row["titulofoto"]}</legend>
              <p class="icon-globe">{$row["NomPais"]}</p>
              <p class="icon-calendar">Fecha: {$row["Fecha"]}</p>
            </fieldset> 
          </footer>
        </figure> 
hereDOC;
}
?>
  </aside>
 </section>
</main>
<!--************************************************************************************-->
<?php    
    require_once('view/inicio.php');
?>
<!--************************************************************************************-->
<?php    
  require_once('view/pie.php');
?>