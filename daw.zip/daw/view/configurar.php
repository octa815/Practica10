<?php
  include("view/cabecera_privada.php");
?>
<?php
  include('model/conexion.php');
  include('model/configurar.php');
?>
<main>
  <fieldset>
    <h2 class="icon-attach">Configurar Estilo</h2>
  </fieldset>

  <fieldset>
    <form method="post" action="">
        <label for="estilo">Selecciona un estilo:</label>
        <select name="estilo" id="estilo">
            <?php
            // Mostrar opciones de estilos desde la base de datos
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<option value='{$row["IdEstilo"]}'>{$row["Nombre"]}</option>";
            }
            ?>
        </select>
        <button type="submit">Guardar</button>
    </form>
  </fieldset>    
</main>
<!--************************************************************************************-->
<?php    
    require_once('view/inicio.php');
?>
<!--************************************************************************************-->
<?php    
  require_once('view/pie.php');
?>